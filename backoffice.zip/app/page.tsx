import { Home } from "@/src/components/refactored"

export default function HomePage() {
  return <Home />
}

