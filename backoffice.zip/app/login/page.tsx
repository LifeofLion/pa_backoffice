import { Login } from "@/src/components/refactored/auth"

export default function LoginPage() {
  return <Login />
}

