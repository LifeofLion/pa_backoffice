import AdminEditAccount from "@/components/back-office/edit-account"

export default function AdminEditAccountPage() {
  return <AdminEditAccount />
}