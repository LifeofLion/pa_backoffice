import NotFoundClient from "@/components/not-found-client"

export default function NotFound() {
  return <NotFoundClient />
}