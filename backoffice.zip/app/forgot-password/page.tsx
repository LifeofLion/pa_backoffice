import { ForgotPassword } from "@/src/components/refactored/auth"

export default function ForgotPasswordPage() {
  return <ForgotPassword />
}

