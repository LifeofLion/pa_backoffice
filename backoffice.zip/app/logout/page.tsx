import { Logout } from "@/src/components/refactored/auth"

export default function LogoutPage() {
  return <Logout />
}

