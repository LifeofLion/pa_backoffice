import { VerificationSuccess } from "@/src/components/refactored/auth"

export default function VerificationSuccessPage() {
  return <VerificationSuccess />
}

