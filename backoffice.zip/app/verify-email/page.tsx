import { VerifyEmail } from "@/src/components/refactored/auth"

export default function VerifyEmailPage() {
  return <VerifyEmail />
}

